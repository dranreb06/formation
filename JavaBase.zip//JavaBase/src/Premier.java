

public class Premier {

	public static void main(String[] args) {
		System.out.println("Je suis votre premier programme Java");
	}
}

