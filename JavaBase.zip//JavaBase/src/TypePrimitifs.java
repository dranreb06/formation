
public class TypePrimitifs {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		float initVal = 12f;
		int retVal, index = 2;
		double gamma = 1.2, brightness = 1.3;
		boolean valueOk = false;
		long veryBig = 12121212121212L;
		

	}
	
	public static int calculAire(int largeur, int longueur) {
		int aire = largeur*longueur;
		return aire;
	}
	
	
}
