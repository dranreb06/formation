package com.formation.poo.innerclasses;

public class Ordinateur {

	
	public class CPU {
		//...
	}
}
