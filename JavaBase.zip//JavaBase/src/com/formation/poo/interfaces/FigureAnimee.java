package com.formation.poo.interfaces;

public interface FigureAnimee  extends Figure {
	public int getVitesseAnimation();
	public int setVitesseAnimation(int vitesse);
}

