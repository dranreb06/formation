package com.formation.poo.interfaces;

import java.awt.Point;

public interface Figure {
	public void dessineToi();
	public void setPosition(Point p);
	public Point getPosition();
}

